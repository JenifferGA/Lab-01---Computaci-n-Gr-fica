export const STEP_SIZE = 30;
